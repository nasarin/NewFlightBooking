package com.gotrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
