package com.gotrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
